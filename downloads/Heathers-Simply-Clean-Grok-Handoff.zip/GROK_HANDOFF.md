# Heather’s Simply Clean Co. — continuation handoff

Prepared October 20, 2026. This document summarizes the owner’s requests and the current website; it is not a set of credentials or proof of image licensing.

## Prompt to give Grok

> Please continue helping me with Heather’s Simply Clean Co.’s website using the attached handoff and website files. Preserve the design I approved. My Instagram is @heatherssimplyclean.co. I want everything to stay free. Do not rename my GitHub account or repository, or change Jazz Nails’ website, without my explicit approval. Read GROK_HANDOFF.md first, inspect the supplied files, and ask what I want to change next. Be clear about which changes are only prepared locally versus actually published.

## Business and brand

- Business: **Heather’s Simply Clean Co.**
- Instagram: **@heatherssimplyclean.co**
- Tagline: **Reliable cleaning. Remarkable results.**
- Services: home cleaning, business/office cleaning, bathroom/kitchen detail, and home organizing (pantries, closets, cabinets).
- Service areas: Santa Clarita, Valencia, and the San Fernando Valley. The owner corrected an earlier place-name error to Valencia.
- The owner’s Instagram screenshot also shows “20 years of experience,” “serving the SCV,” and `DM "QUOTE" or tap the link to book`. These are owner-provided profile claims, not independently verified.
- Visual direction: black-and-white brand, professional and commercial, mobile-friendly, distinctive and polished rather than a generic AI-template site.

## Current public website

**https://pedrinloco74-afk.github.io/San-Ysidro-waits-/heathers-simply-clean/**

This is the working public link. Latest GitHub Pages deployment was confirmed successful via GitHub Actions:

- Commit: `d8c10770f6eb1916108e09dbce3802cf0d09dc85`
- Run ID: `39483767134`
- Run URL: https://github.com/pedrinloco74-afk/San-Ysidro-waits-/actions/runs/39483767134

The previous agent could not directly fetch the public Pages URL because of its network allowlist; publication verification relied on the successful GitHub deployment status. Do not claim independent browser testing of the live site from this handoff.

## Hosting and repository — protect the other website

- Repository: https://github.com/pedrinloco74-afk/San-Ysidro-waits-
- Heather’s working branch: `arena/baff07a8-san-ysidro-waits`
- Jazz Nails source branch: `arena/99e2a0c9-san-ysidro-waits`
- The root public URL serves **Jazz Nails**: https://pedrinloco74-afk.github.io/San-Ysidro-waits-/
- Heather’s site must remain at the separate `/heathers-simply-clean/` path unless explicitly authorized otherwise.
- The combined workflow is supplied under `deployment-reference/deploy-pages.yml`. It builds Jazz Nails using Node 22 and its Vite base `/San-Ysidro-waits-/`, then places Heather’s static website in `dist/heathers-simply-clean/` before deploying both to Pages.
- Do not replace the combined deployment with a Heather-only root deployment in this shared repository.
- GitHub Pages environment restrictions were removed by the owner. Push-triggered deployments work; previous manual workflow-dispatch attempts were denied by the integration. Never request passwords, access tokens, or two-factor codes in chat.
- The website files in this export are the current local implementation. At handoff time the local Git index unexpectedly showed only the initial README tracked, while the remote working branch correctly pointed at the deployed commit above. If reconnecting to the existing checkout, inspect local and remote state and preserve files before any reset/pull. Do not blindly force-push an old local history.

## Owner’s approved design details

- The owner said they love the website.
- Real cleaning/organizing photos, no faces. Do not generate replacements unless the owner changes that preference.
- Before/after examples should match the same fixture/space and show actual grime/clutter changes, not a contrast or brightness trick.
- Organization pictures should show containers, labeled bins, clear food containers, and grouped essentials.
- Photos now appear in the opening section; on mobile they appear before the headline. The gallery appears before services.
- The owner asked to remove all writing directly underneath pictures, source captions, and “not my work” captions. The deployed site has no visible figure captions. It retains a neutral “Cleaning & organizing inspiration” heading and inspiration descriptions rather than claiming these are Heather’s projects.
- The latest fix lets photo frames follow the original image proportions with `width: 100%`, `height: auto`, and `object-fit: contain`. Avoid forcing wide or square crops on portraits or cutting off half of a before/after comparison.
- Photos open in a dialog/lightbox, with a close button and native Escape support.
- A dark editorial brand-promise section gives a testimonial-like visual feel without fabricated reviews or customer identities.
- A fixed mobile quote button and service-priority chips help visitors prepare an inquiry.

## Important: inquiry form is not a booking system

The quote form creates and copies a message on the visitor’s device. It does **not** send email, store submissions, submit a lead, book an appointment, or send an Instagram DM automatically. Visitors must paste the copied message into Instagram themselves. The site explains this. Preserve that disclosure unless implementing and testing a real backend/integration.

## Image provenance and unresolved licensing issue

The supplied photographs were retrieved online. **No commercial-use license or owner permission was verified. Attribution alone is not permission. Do not describe these images as public domain, licensed free stock, or actual Heather client work.** The owner asked for free images without permission outreach and approved these references, but that does not establish rights from the photo owners.

The exported `website/assets/references/SOURCES.md` records the origins. Current visible images:

- `bathroom-before-after.jpg`: iStock bathroom collection, photo ID 1548255311, “Bathroom sink and faucet transformation.” Source: https://www.istockphoto.com/photos/bathroom-before-and-after . It is a search-preview image, not a purchased stock download.
- `pantry-clear-containers.jpg`: Pretty Providence’s pantry project, clear cereal containers and labeled bins. Source: https://prettyprovidence.com/pantry-organization/ . Original: https://prettyprovidence.com/wp-content/uploads/2019/03/cereal-wall.jpg .
- `pantry-labeled-bins.jpg`: Same project, labeled bins and storage zones. Original: https://prettyprovidence.com/wp-content/uploads/2019/03/pantry-back-after.jpg .

Existing image branding was not deliberately removed from the source files. The pantry images are finished organizing references, not a fabricated before/after pair. Recommended future resolution: replace third-party examples with Heather’s own authorized photos or genuine, verified free-commercial-use imagery while preserving the approved layout. Never silently claim the licensing issue has been resolved.

Earlier generated images and unused searches are intentionally excluded from this export.

## Link-name discussion — latest owner decision

The owner dislikes the GitHub username and unrelated repository name appearing in the Instagram bio link. Their screenshot confirmed Instagram was displaying the actual GitHub Pages address despite entering a link title.

- Changing a link title does not reliably change Instagram’s displayed URL/domain.
- Editing HTML cannot remove the GitHub account name from a GitHub Pages hostname.
- Renaming the GitHub account affects the whole account; GitHub usernames cannot contain periods.
- Renaming this repository changes the Pages path and can affect Jazz Nails too.
- A free Netlify subdomain such as `heatherssimplyclean-co.netlify.app` was proposed, but availability has **not** been checked and the address has **not** been registered or published.
- A static upload ZIP was prepared for free hosting, but no Netlify account or deployment was created. A free-hosting provider account/login would require the owner’s participation or an authorized connection.
- Latest owner instruction: **“No, don’t worry about it. How about you create something so I can just export to a Grok Bot and they can continue this.”** No repository or account rename was performed. Do not resume renaming on the assumption that it is approved.

## What is in the export ZIP

- `GROK_HANDOFF.md`: this context and continuation prompt.
- `website/index.html`: complete responsive single-file HTML/CSS/JS site.
- `website/assets/heathers-simply-clean-logo.png`: existing brand logo.
- `website/assets/references/`: the three currently used photos and provenance notes.
- `deployment-reference/deploy-pages.yml`: combined GitHub Pages workflow for context; do not blindly apply it to unrelated hosting.
- `START_HERE.txt`: short upload/use instructions.

No credentials, Git metadata, account tokens, search caches, or generated-image drafts are included.

## Running or publishing the supplied website

For local viewing, serve the `website/` directory with a static server, for example:

```sh
python -m http.server 4173 --bind 0.0.0.0 --directory website
```

It has no npm dependencies or build step. For a standalone free static host, upload the contents of `website/` with `index.html` at the publish root. For the existing shared GitHub Pages site, preserve the supplied combined workflow and Heather’s separate subpath.

## Tests completed before the latest deployment

- Local image-file existence and alt attributes.
- Internal anchor targets and unique IDs during earlier edits.
- JavaScript syntax with Node.
- Git whitespace/diff checks.
- CSS checks confirming no forced photo aspect-ratio crop and no `object-fit: cover`.
- Successful combined GitHub Pages workflow.

No comprehensive automated browser interaction or visual-regression suite was run. Grok should test mobile/desktop photo sizing, lightbox controls, keyboard behavior, and quote-copy behavior before making further changes.
